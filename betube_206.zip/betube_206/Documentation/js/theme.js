/*
* @Author: hassan
* @Date:   2016-05-23 12:52:49
* @Last Modified by:   hassan
* @Last Modified time: 2016-05-23 12:52:53
*/

'use strict';
$(document).foundation();